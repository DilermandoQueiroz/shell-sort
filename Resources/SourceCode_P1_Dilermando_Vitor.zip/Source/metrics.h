#ifndef METRICS_H
#define METRICS_H

struct Metrics {
    long long comparisons;
    long long movements;
    double time_us;
};

#endif // METRICS_H
